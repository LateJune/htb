<?php

return [
	'defaults' => [],
	'endpoints' => [],
];
